<?php
$_['heading_title'] = 'Welcome to %s';
?>